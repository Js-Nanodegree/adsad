const { PubSub } =require ('apollo-server')

const WebSocket = require('ws');
const ws = new WebSocket('ws://localhost:8000');

const pubsub = new PubSub()
const MESSAGE_CREATED = 'MESSAGE_CREATED'

const resolvers = {
	Query: {
		messages: () => [{ id: 0, content: 'Hello!' }, { id: 1, content: 'Bye!' }],
	},
	Subscription: {
		messageCreated: {
			subscribe: () => pubsub.asyncIterator(MESSAGE_CREATED),
		},
	},
}


 
ws.on('open', function open() {
  ws.send('something');
});

let id = 2
 
ws.on('message', function incoming(data) {
	pubsub.publish(MESSAGE_CREATED, {
		messageCreated: { id, content: data },
	})
});



module.exports = resolvers